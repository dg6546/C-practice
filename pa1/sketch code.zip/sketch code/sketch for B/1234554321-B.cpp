#include "ListNode.h"

ListNode * SolveB(int n){
    /* your code starts here */
    //construct a list accrording to input


    //rearrange the list

}