#include <iostream>
#include <string>
using namespace std;


class Stack{
private:

public:
    Stack();
    void push(int element);
    int pop();
    int isEmpty();
};


void SolveA() {
    string s;
    Stack st;
    for (int i = 0; i < 1000; i++) {
        getline(cin, s);

        /* your code starts here */

}

int main() {
    SolveA();
    return 0;
}