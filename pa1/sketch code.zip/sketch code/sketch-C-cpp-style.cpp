#include <iostream>
#include <string>
using namespace std;

void SolveC(){
    string s;
    cin >> s;

    /* your code starts here */
}

int main() {
    SolveC();
    return 0;
}