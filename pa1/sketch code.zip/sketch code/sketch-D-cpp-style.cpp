#include <iostream>
using namespace std;

void SolveD () {
    /* your code starts here */

}
int main() {
    SolveD();
    return 0;
}