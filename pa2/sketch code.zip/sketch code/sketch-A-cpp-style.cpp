#include <iostream>
#include <math.h>
using namespace std;

// Definition for a binary tree node.
struct TreeNode {
    int val;
    int max; // maximum value of the subtree from this node
    int min; // minimum value of the subtree from this node
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), max(NULL), min(NULL), left(NULL), right(NULL) {}
    TreeNode() : val(NULL), max(NULL), min(NULL), left(NULL), right(NULL)  {}
};

void SolveD() {

}

int main() {
    SolveD();
    return 0;
}